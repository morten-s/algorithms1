import edu.princeton.cs.algs4.QuickUnionUF;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class PercolationStats {
    private double[] meanArray;
    private int trials;
	private Percolation pTest;
    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int t){
        trials = t;
        meanArray = new double[trials]; 
        for(int i = 0; i < trials; i++){
            pTest = new Percolation(n);
            int rolls = 0;
            while(!pTest.percolates()){
                int row = (int)(StdRandom.uniform()*n) + 1; // adjust to startrow = 1
                int col = (int)(StdRandom.uniform()*n) + 1;
                pTest.open(row, col);
                rolls++;
            }
            // fraction mean number opensites/gridsize
            meanArray[i] = (double)pTest.numberOfOpenSites() / (double)(n*n);
            System.out.println("xover:" + ((double)pTest.numberOfOpenSites() / (double)(n*n)) + " Opensites: " + pTest.numberOfOpenSites());
           /*
            System.out.println(pTest.QUarray.count());
            printGrid(pTest, nArg);*/
        }
    	System.out.println("Trials: " + trials + "gridsize: " + n + "*" + n);
    }

    // sample mean of percolation threshold
    public double mean(){
        return ( StdStats.mean(meanArray) );
    }

    // sample standard deviation of percolation threshold
    public double stddev(){
        return ( StdStats.stddev(meanArray) );
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo(){
        return 1;
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi(){
        return 1;
    }

   // test client (see below)
   public static void main(String[] args){
        int n = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        PercolationStats pstat = new PercolationStats(n, t);
        System.out.println("mean = " + pstat.mean());
        System.out.println("stddev = " + pstat.stddev());
        System.out.println("95% confidence interval = ["+ pstat.confidenceLo() + ", " + pstat.confidenceHi() + "]");

   }

}